package com.tarun;

public class ExceptionConfig {
    private String name;
    private int sev;
    private int priority;

    public ExceptionConfig(String name, int sev, int priority) {
        this.name = name;
        this.sev = sev;
        this.priority = priority;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSev() {
        return sev;
    }

    public void setSev(int sev) {
        this.sev = sev;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }
}
