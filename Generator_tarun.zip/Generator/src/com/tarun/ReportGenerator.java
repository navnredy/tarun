package com.tarun;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class ReportGenerator {

    public void generateReport(String zipFilePath, String configCSV, String linesConfig) {

        String tempDir = System.getProperty("java.io.tmpdir") + File.separator + "extractfolder";
        try (BufferedReader reader = new BufferedReader(new FileReader(configCSV));
             FileInputStream fis = new FileInputStream(linesConfig);
             ZipFile zipFile = new ZipFile(zipFilePath)) {


            // STEP-1: Read linesconfig.properties file and store it in Properties class
            Properties properties = new Properties();
            properties.load(fis);
            int linesBefore = Integer.parseInt(properties.getProperty("linesbefore"));
            int linesAfter = Integer.parseInt(properties.getProperty("linesafter"));

            String outputLocation = properties.getProperty("reportdirectory");

            // STEP-2: Read config.csv and store
            Set<String> exceptionList = new HashSet<>();
            Map<String, StringBuilder> exceptionBuilderMap = new HashMap<>();
            String line;
            boolean ignoreHeader = true;
            while ((line = reader.readLine()) != null) {
                if(ignoreHeader) {
                    ignoreHeader = false;
                    continue;
                }

                String[] values = line.split(",");
                exceptionList.add(values[0]);
                exceptionBuilderMap.put(values[0], new StringBuilder());
            }


            // STEP-3: Extract zip file into a temporary directory
            Enumeration<? extends ZipEntry> entries = zipFile.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                String entryName = entry.getName();
                Path entryPath = Paths.get(tempDir, entryName);

                if (!entry.isDirectory()) {
                    extractFile(zipFile, entry, entryPath);
                } else {
                    Files.createDirectories(entryPath);
                }
            }

            // STEP-4: Read files from extracted files location
            File folder = new File(tempDir);
            Path path = Paths.get(outputLocation);
            if(!Files.exists(path)) {
                try {
                    Files.createDirectories(path);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            FileWriter writer = new FileWriter(outputLocation+File.separator+"report.txt", false);
            readFilesFromFolder(folder, exceptionList,linesBefore, linesAfter, exceptionBuilderMap);

            for (String exception:
                 exceptionList) {
                StringBuilder exceptionBuilder = exceptionBuilderMap.get(exception);
                writer.write(exceptionBuilder.toString());
                writer.flush();
            }

            System.out.println("Report is generated @ "+ folder.getName());

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                deleteDirectory(tempDir);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void extractFile(ZipFile zipFile, ZipEntry entry, Path filePath) throws IOException {
        try (InputStream inputStream = zipFile.getInputStream(entry);
             BufferedOutputStream outputStream = new BufferedOutputStream(Files.newOutputStream(filePath))) {
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
        }
    }

    private void deleteDirectory(String directoryPath) throws IOException {
        Path path = Path.of(directoryPath);
        if (Files.exists(path)) {
            Files.walk(path)
                    .sorted((p1, p2) -> -p1.compareTo(p2))
                    .forEach(p -> {
                        try {
                            Files.delete(p);
                        } catch (IOException e) {
                            throw new RuntimeException("Failed to delete file: " + e.getMessage());
                        }
                    });
        } else {
            throw new IOException("Directory does not exist.");
        }
    }

    private void readFilesFromFolder(File folder, Set<String> exceptionList, int linesBefore, int linesAfter, Map<String, StringBuilder> exceptionBuilderMap) {
        File[] files = folder.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isFile()) {
                    try (BufferedReader reader = new BufferedReader(new FileReader(file))) {

                        String line;
                        Queue<String> beforelines = new LinkedList<>();
                        Queue<String> afterlines = new LinkedList<>();
                        boolean containsException = false;
                        String exceptionType = null;

                        while ((line = reader.readLine()) != null) {
                            for (String exception : exceptionList) {
                                if (line.contains(exception)) {
                                    containsException = true;
                                    exceptionType = exception;
                                    break;
                                }
                            }
                            if (!containsException && (beforelines.size() == linesBefore)) {
                                beforelines.poll();
                            }
                            if (containsException && afterlines.size() < linesAfter + 1) {
                                afterlines.add(line);
                            }
                            if (!containsException)
                                beforelines.add(line);

                            if (afterlines.size() == linesAfter + 1) {
                                StringBuilder exceptionBuilder = exceptionBuilderMap.get(exceptionType);
                                for (String current : beforelines
                                ) {
                                    exceptionBuilder.append(current).append("\n");
                                    //writer.write(current + "\n");
                                }

                                for (String current : afterlines
                                ) {
                                    exceptionBuilder.append(current).append("\n");
                                   //writer.write(current + "\n");
                                }

                                beforelines = new LinkedList<>();
                                afterlines = new LinkedList<>();
                                exceptionType = null;
                                containsException = false;
                            }
                        }


                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else if (file.isDirectory()) {
                    readFilesFromFolder(file, exceptionList, linesBefore, linesAfter, exceptionBuilderMap); // Recursive call for subdirectories
                }
            }
        }
    }
}


