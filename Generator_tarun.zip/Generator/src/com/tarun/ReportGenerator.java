package com.tarun;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class ReportGenerator {

    private String outputLocation;
    private int linesBefore;
    private int linesAfter;
    private Set<String> exceptionList = new HashSet<>();
    private Map<String, StringBuilder> exceptionBuilderMap = new HashMap<>();
    private Map<Integer, Map<Integer, Set<String>>> exceptionOrderList = new TreeMap<>();

    private void readProperties(String propertiesFile) {
        try (FileInputStream fis = new FileInputStream(propertiesFile)) {
            Properties properties = new Properties();
            properties.load(fis);
            linesBefore = Integer.parseInt(properties.getProperty("linesbefore"));
            linesAfter = Integer.parseInt(properties.getProperty("linesafter"));
            outputLocation = properties.getProperty("reportdirectory");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void readCSV(String configCSV) {
        try (BufferedReader reader = new BufferedReader(new FileReader(configCSV))) {

            String line;
            boolean ignoreHeader = true;
            while ((line = reader.readLine()) != null) {
                if(ignoreHeader) {
                    ignoreHeader = false;
                    continue;
                }

                String[] values = line.split(",");
                int sev = Integer.parseInt(values[1]);
                int priority = Integer.parseInt(values[2]);
                String exceptionName = values[0];
                exceptionList.add(exceptionName);
                exceptionBuilderMap.put(exceptionName, new StringBuilder());


                Map<Integer, Set<String>> currentExceptionConfig = exceptionOrderList.get(sev);
                if (currentExceptionConfig == null) {
                    currentExceptionConfig = new TreeMap<>();
                    exceptionOrderList.put(sev, currentExceptionConfig);
                }
                Set<String> currentExceptionList = currentExceptionConfig.get(priority);
                if (currentExceptionList == null) {
                    currentExceptionList = new HashSet<>();
                    currentExceptionConfig.put(priority, currentExceptionList);
                }
                currentExceptionList.add(exceptionName);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void extractZip(String zipFilePath, String tempDir) {
        try (ZipFile zipFile = new ZipFile(zipFilePath)) {

            Enumeration<? extends ZipEntry> entries = zipFile.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                String entryName = entry.getName();
                Path entryPath = Paths.get(tempDir, entryName);

                if (!entry.isDirectory()) {
                    extractFile(zipFile, entry, entryPath);
                } else {
                    Files.createDirectories(entryPath);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void writeReport() {
        try {
            for (Integer sev:
                    exceptionOrderList.keySet()) {
                Map<Integer, Set<String>> currentExceptionInfo = exceptionOrderList.get(sev);
                FileWriter writer = null;
                for (Integer priority:
                        currentExceptionInfo.keySet()) {
                    for (String exception:
                            currentExceptionInfo.get(priority)) {
                        StringBuilder exceptionBuilder = exceptionBuilderMap.get(exception);
                        if(!exceptionBuilder.isEmpty()) {
                            if(writer == null) {
                                writer = new FileWriter(outputLocation + File.separator + sev + ".txt", false);
                            }
                            writer.write(exceptionBuilder.toString());
                            writer.flush();
                        }
                    }

                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void generateReport(String zipFilePath, String configCSV, String linesConfig) {

        long startTime = System.currentTimeMillis();
        String tempDir = System.getProperty("java.io.tmpdir") + File.separator + "extractfolder";


        // STEP-1: Read linesconfig.properties file and store it in Properties class
        readProperties(linesConfig);

        // STEP-2: Read config.csv and store
        readCSV(configCSV);

        // STEP-3: Extract zip file into a temporary directory
        extractZip(zipFilePath, tempDir);

        // STEP-4: Read files from extracted files location
        File folder = new File(tempDir);
        Path path = Paths.get(outputLocation);
        if(!Files.exists(path)) {
            try {
                Files.createDirectories(path);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        readFilesFromFolder(folder,tempDir);

        // STEP-5: Generate Reports
        writeReport();

        // STEP-6: delete temp directory's extracted folder
        try {
            deleteDirectory(tempDir);
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Report is generated @ "+ outputLocation);
        System.out.println("Time taken to generate Report: "+ (System.currentTimeMillis() - startTime) + "ms");

    }

    private void extractFile(ZipFile zipFile, ZipEntry entry, Path filePath) throws IOException {
        try (InputStream inputStream = zipFile.getInputStream(entry);
             BufferedOutputStream outputStream = new BufferedOutputStream(Files.newOutputStream(filePath))) {
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
        }
    }

    private void deleteDirectory(String directoryPath) throws IOException {
        Path path = Path.of(directoryPath);
        if (Files.exists(path)) {
            Files.walk(path)
                    .sorted((p1, p2) -> -p1.compareTo(p2))
                    .forEach(p -> {
                        try {
                            Files.delete(p);
                        } catch (IOException e) {
                            throw new RuntimeException("Failed to delete file: " + e.getMessage());
                        }
                    });
        } else {
            throw new IOException("Directory does not exist.");
        }
    }

    private void readFilesFromFolder(File folder, String tempDir) {
        File[] files = folder.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isFile()) {
                    try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                        String line;
                        Queue<String> beforelines = new LinkedList<>();
                        Queue<String> afterlines = new LinkedList<>();
                        boolean containsException = false;
                        String exceptionType = null;
                        int lineNumber = 1;
                        String fileName = file.getName();
                        while ((line = reader.readLine()) != null) {
                            for (String exception : exceptionList) {
                                if (line.contains(exception)) {
                                    containsException = true;
                                    exceptionType = exception;
                                    break;
                                }
                            }
                            if (!containsException && (beforelines.size() == linesBefore)) {
                                beforelines.poll();
                            }
                            StringBuilder builder = new StringBuilder();
                            builder.append("[Exception in file ").append(fileName).append(" - line number: ").append(lineNumber).append("] : ");
                            builder.append(line);
                            if (containsException && afterlines.size() < linesAfter + 1) {
                                afterlines.add(builder.toString());
                            }
                            if (!containsException) {
                                beforelines.add(builder.toString());
                            }

                            if (afterlines.size() == linesAfter + 1) {
                                StringBuilder exceptionBuilder = exceptionBuilderMap.get(exceptionType);
                                for (String current : beforelines
                                ) {
                                    exceptionBuilder.append(current).append("\n");
                                }

                                for (String current : afterlines
                                ) {
                                    exceptionBuilder.append(current).append("\n");
                                }

                                beforelines = new LinkedList<>();
                                afterlines = new LinkedList<>();
                                exceptionType = null;
                                containsException = false;
                            }
                            lineNumber++;
                        }


                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else if (file.isDirectory()) {
                    readFilesFromFolder(file, tempDir); // Recursive call for subdirectories
                }
            }
        }
    }
}


