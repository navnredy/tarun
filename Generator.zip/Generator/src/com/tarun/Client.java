package com.tarun;

public class Client {
    public static void main(String[] args) {
        ReportGenerator reportGenerator = new ReportGenerator();
        reportGenerator.generateReport("D:\\IntelliJ\\Report\\Generator\\src\\Input.zip", "D:\\IntelliJ\\Report\\Generator\\src\\config.csv", "D:\\IntelliJ\\Report\\Generator\\src\\linesconfig.properties");
    }
}
